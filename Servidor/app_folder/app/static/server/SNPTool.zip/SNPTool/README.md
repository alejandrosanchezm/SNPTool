# Modelo de SNP Tool para la clasificación entre benigno y patógeno ##

### 1. Instalamos las librería Joblib, Numpy y ScikitLearn:
    
    - pip install joblib, sklearn, numpy

### 2. Importamos desde joblib la función load como se indica en la documentación: 
https://joblib.readthedocs.io/en/latest/generated/joblib.load.html

    >>> from joblib import load
    >>> without_amino = load('without_amino.joblib')

### 3. A partir de aquí, podremos predecir los valores introduciendo como entrada
los valores de Cromosoma, Posición, Base de Referencia y Base Alternativa, bayesAdd score, bayesNo  score y ClinPred  score, o
bien en formato de numpy array o bien como Pandas DataFrame.
Los valores categóricos utilizan el siguiente diccionario para la codificación

    >>> bases = {'A': 0, 'C': 1, 'G': 2, 'T': 3}

Así mismo, el cromosoma X se codifica como 23, mientras que el resto mantienen la 
numeración.

    >>> X = df[['cromosoma','posicion','referencia','alternativa','bayesAdd','bayesNo','clinPred']]
    >>> y_pred = without_amino.predict(X)

Los scores pueden ser extraídos o bien de los modelos que se encuentran en la página de SNP Tool,
o de los datasets de las páginas oficiales correspondientes (indicadas en la página de SNP Tool).

La documentación del Random Forest Classifier se encuentra en el siguiente enlace:
https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html